E02 dimensional fit prototypes only. STL units mm. No flight qualification. See interfaces.pdf and README.md.
