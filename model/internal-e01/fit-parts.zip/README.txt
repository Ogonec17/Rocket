E01 FIT CHECK ONLY. STL units: millimetres. Not flight-qualified.
See accompanying README and interfaces.pdf.
