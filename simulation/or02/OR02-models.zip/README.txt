OR02: 15 TEST cases, OpenRocket 24.12, ascent only. Import K535W-REF.rse first.
Base: A04, payload 1.5 kg, K535W-REF, effective rail 4 m vertical, latitude45 longitude0, spherical Earth,
ISA at sea level 15 degC / 101325 Pa, Normal60 micrometre finish, no wind, timestep0.02s.
cases.json lists changes relative to that base. Profile wind levels are MSL, zero turbulence.
Temperature cases use extended ISA at sea level and 101325 Pa.
Simulation ends at apogee through the bundled stock ApogeeEndListener. Recovery is not modelled.
Verification seed20260930; ORK1.10 does not persist seed, GUI replay may differ slightly.
E01 is a fit prototype mass comparison only. CG x coordinate is measured from the nose.
Pressure lag tau values are assumptions, not measured sensor or vent properties.
Motor is a digitized reference, not the assigned competition engine; inputs are unvalidated.
Full assumptions and source limits: https://github.com/Ogonec17/Rocket/blob/main/simulation/or02/README.md
